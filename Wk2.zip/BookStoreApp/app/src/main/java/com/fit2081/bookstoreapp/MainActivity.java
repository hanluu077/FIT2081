package com.fit2081.bookstoreapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button getAddbook_btn, getClear_fields;
    EditText getBookID, getTitle, getAuthor, getISBN, getDescription, getPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onDisplay(View v){
        getAddbook_btn = findViewById(R.id.btnAddbook);
        getClear_fields = findViewById(R.id.btnClear_fields);
        
        getBookID = (EditText)findViewById(R.id.bookID_input);
        getTitle = (EditText)findViewById(R.id.title_input);
        getAuthor = (EditText)findViewById(R.id.author_input);
        getISBN = (EditText)findViewById(R.id.ISBN_input);
        getDescription = (EditText)findViewById(R.id.description_input);
        getPrice = (EditText)findViewById(R.id.price_input);


        getAddbook_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String printTitle = getTitle.getText().toString();
                float printPrice = Float.parseFloat(getPrice.getText().toString());
                String msg = "Title: (" + printTitle + ") Price: ($" + String.format("%.2f", printPrice) + ")";

                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });

        getClear_fields.setOnClickListener(view -> {
            getBookID.getText().clear();
            getTitle.getText().clear();
            getAuthor.getText().clear();
            getISBN.getText().clear();
            getDescription.getText().clear();
            getPrice.getText().clear();

        });
    }
}


