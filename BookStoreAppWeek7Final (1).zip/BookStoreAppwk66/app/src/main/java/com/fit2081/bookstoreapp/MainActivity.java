package com.fit2081.bookstoreapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {
    public static final String TAG = "BOOK";

    Button getAddbook_btn, getClear_fields_btn, getLoadBook_btn;
    EditText getBookID, getTitle, getAuthor, getISBN, getDescription, getPrice;
//    SharedPreferences sp = getSharedPreferences("MatchName", MODE_PRIVATE);

    public static final String MY_PREF_FILENAME = "com.fit2081.bookstoreapp.data";
    private String Title;
    public static String BOOK_KEY= "book_key";

    ArrayList<String> dataSource;
    ArrayList<Item> data = new ArrayList<>();
    ListView listview;
    ArrayAdapter adapter;
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    RecyclerView recyclerView;
    RecyclerAdapter myRecyclerAdapter;

    private BookViewModel bookViewModel;
    public static int counter = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        setContentView(R.layout.drawer_layout); // made my own layout, replace default

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar); // removed the default toolbar from setContentView, and now we have set the toolbar with title and triple dots

//        Link the toolbar with the action bar (hamburger 3 lines)
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav); // need to go to folder Values > Strings.xlm to create 'open_nav' and 'close_nav'
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

//        Comment out because buttons were removed
//        getAddbook_btn = findViewById(R.id.btnAddbook);
//        getClear_fields_btn = findViewById(R.id.btnClear_fields);
//        getLoadBook_btn = findViewById(R.id.loadBook_btn);

        getBookID = findViewById(R.id.bookID_input);
        getTitle = findViewById(R.id.title_input);
        getAuthor = findViewById(R.id.author_input);
        getISBN = findViewById(R.id.ISBN_input);
        getDescription = findViewById(R.id.description_input);
        getPrice = findViewById(R.id.price_input);

        dataSource = new ArrayList();
        listview = findViewById(R.id.listViewID);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataSource); // (1) context - get information about my application, (2) using predefined layout(eg themes, formatting, UI placements), (3) dataSource
        listview.setAdapter(adapter);

        navigationView.setNavigationItemSelectedListener(new navigationHandler());
        adapter.notifyDataSetChanged();

//        -------- WEEK 6 -----
        recyclerView = findViewById(R.id.recViewID);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        myRecyclerAdapter = new RecyclerAdapter();
        myRecyclerAdapter.setData(data);
        recyclerView.setAdapter(myRecyclerAdapter);

//        ----

//        FAB - FLOATING ACTION BUTTON
//        FloatingActionButton fab = findViewById(R.id.fab);
        fabOnClick();

//        --- Week 7
//        bookViewModel = new ViewModelProvider(this).get(BookViewModel.class);
//        Books book = new Books(getTitle.getText().toString(), getAuthor.getText().toString(), getISBN.getText().toString(), getDescription.getText().toString(),getPrice.getText().toString());
//        BookViewModel.insert(book);

    }

    public void addBook(){
        bookViewModel = new ViewModelProvider(this).get(BookViewModel.class);
        Books book = new Books(getTitle.getText().toString(), getAuthor.getText().toString(), getISBN.getText().toString(), getDescription.getText().toString(),getPrice.getText().toString());
        BookViewModel.insert(book);
    }

    public void addItem() {

//        Item book = new Item(getBookID.getText().toString() ,getTitle.getText().toString(), getAuthor.getText().toString(), getISBN.getText().toString(), getDescription.getText().toString(),getPrice.getText().toString());
        Item book = new Item(counter + "", getTitle.getText().toString(), getAuthor.getText().toString(), getISBN.getText().toString(), getDescription.getText().toString(),getPrice.getText().toString());
        data.add(book);
        myRecyclerAdapter.notifyDataSetChanged();

    }
    public void listAllBooks(){

        Gson gson = new Gson ();
        String movieDataStr = gson.toJson(data);

        Intent intent = new Intent (this, MainActivity2.class);
        intent.putExtra(BOOK_KEY,movieDataStr);
        startActivity(intent);

    }

    class navigationHandler implements NavigationView.OnNavigationItemSelectedListener{

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            int id = item.getItemId();
            if (id == R.id.nav_menu_add_book) {
                getText();

            }
            else if (id == R.id.nav_menu_remove_last_book) {
                int index = dataSource.size() - 1;
                dataSource.remove(index);
                adapter.notifyDataSetChanged();
                Toast.makeText(MainActivity.this,"Last Book Removed", Toast.LENGTH_LONG).show();

            }
            else if (id == R.id.nav_menu_remove_all_books) {
                dataSource.clear();
                adapter.notifyDataSetChanged();
                Toast.makeText(MainActivity.this,"ListView Cleared", Toast.LENGTH_LONG).show();

            }
            else if (id == R.id.nav_num_of_items_in_list) {
                int numList = dataSource.size();
                Toast.makeText(MainActivity.this,"List Size: " + numList, Toast.LENGTH_LONG).show();

            }
            drawerLayout.closeDrawers();


            return true;

        }
//            int id = item.getItemId();
//            switch (id){
//                case R.id.nav_menu_add_book:
//                    break;
//                case R.id.nav_menu_remove_last_book:
//                    break;
//                case R.id.nav_menu_remove_all_books:
//                    Toast.makeText(MainActivity.this, "Test pass", Toast.LENGTH_LONG).show();
//                    adapter.clear();
//
//                    break;
//            }
//            drawerLayout.closeDrawers();
//            return true;
//        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
//        return super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.nav_option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        return super.onOptionsItemSelected(item);
        int id = item.getItemId();
        if (id == R.id.options_menu_clear_fields) {
            clearFields();
        }
        else if (id == R.id.options_menu_load_data) {
            loadBook();
        }
        else if (id == R.id.options_remove_last_book) {
            int index = dataSource.size() - 1;
            dataSource.remove(index);
            adapter.notifyDataSetChanged();
            Toast.makeText(MainActivity.this,"Last Book Removed", Toast.LENGTH_LONG).show();

        }
        else if (id == R.id.options_remove_all_books) {
            dataSource.clear();
            adapter.notifyDataSetChanged();
            Toast.makeText(MainActivity.this,"ListView Cleared", Toast.LENGTH_LONG).show();
            bookViewModel.deleteAll();
        }
        else if (id == R.id.options_num_of_items_in_list) {
            int numList = dataSource.size();
            Toast.makeText(MainActivity.this,"List Size: " + numList, Toast.LENGTH_LONG).show();

        }
        else if (id == R.id.options_menu_view_all_books) {
            listAllBooks();
        }
            return true;
    }
//    FAB BUTTON
    public void fabOnClick(){
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                getText();
                addItem();
                counter ++;
                addBook();
            }

        });
    }


    public void clearFields() {
        getBookID.getText().clear();
        getTitle.getText().clear();
        getAuthor.getText().clear();
        getISBN.getText().clear();
        getDescription.getText().clear();
        getPrice.getText().clear();
    }
    public void loadBook(){
        getBookID.setText("book");
        getTitle.setText("title");
        getAuthor.setText("author");
        getISBN.setText("isbn");
        getDescription.setText("des");
        getPrice.setText("100");
    }

   public void getText(){
        String printGetBookTitle = getTitle.getText().toString();
        String printGetPrice = getPrice.getText().toString();
        dataSource.add(printGetBookTitle + " | " + printGetPrice);
        adapter.notifyDataSetChanged();//  EVERY TIME you update the datasource, need to trigger the adapter - "Hey, I made a new update, check it out Adapter!"
       //add data to the listview
    }
















//    -----------------------------------------
        public void sms(){
        /* Request permissions to access SMS */
        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS, android.Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 0);
        /* Create and instantiate the local broadcast receiver
           This class listens to messages come from class SMSReceiver
         */
        MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver();

        /*
         * Register the broadcast handler with the intent filter that is declared in
         * class SMSReceiver @line 11
         * */
        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER));

    }
    class MyBroadCastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);

            StringTokenizer sT = new StringTokenizer(msg, "|");
            String bookIDToken = sT.nextToken();
            String titleToken = sT.nextToken();
            String authorToken = sT.nextToken();
            String ISBNToken = sT.nextToken();
            String descriptionToken = sT.nextToken();
            String priceToken = sT.nextToken();

            getBookID.setText(bookIDToken);
            getTitle.setText(titleToken);
            getAuthor.setText(authorToken);
            getISBN.setText(ISBNToken);
            getDescription.setText(descriptionToken);
            getPrice.setText(priceToken);

        }


//        getLoadBook_btn.setOnClickListener(view -> {
//            SharedPreferences.Editor editor = getSharedPreferences("MY_PREF_FILENAME", MODE_PRIVATE).edit();
//            editor.putString("TheBookID", printBookID);
//            editor.apply();
//            getBookID.setText(TheBookID);
//
//            SharedPreferences.Editor editor = getSharedPreferences("MY_PREF_FILENAME", MODE_PRIVATE).edit();
//            editor.putString("TheBookID", printBookID);
//            editor.apply();
////
//        });
    }
    // For getBook ID Comment out because button is removed
//    public void onDisplay(View v) {
//        String printBookID = getBookID.getText().toString();
//        String printTitle = getTitle.getText().toString();
//        String printAuthor = getAuthor.getText().toString();
//        String printISBN = getISBN.getText().toString();
//        String printDescription = getDescription.getText().toString();
//        float printPrice = Float.parseFloat(getPrice.getText().toString());
//
//        getAddbook_btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String msg = "Title: (" + printTitle + ") Price: ($" + String.format("%.2f", printPrice) + ")";
//                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
//                getText();
//            }
//        });
    //        getClear_fields_btn.setOnClickListener(view -> {
//            clearFields();
//        });

//
//    }

}


